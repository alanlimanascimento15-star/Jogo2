Notas: Versão coop em tela dividida.
