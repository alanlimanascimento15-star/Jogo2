// Stub for coop version
int main(){return 0;}