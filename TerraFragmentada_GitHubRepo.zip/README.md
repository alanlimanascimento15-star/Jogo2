Terra Fragmentada — FINAL Singleplayer Package (Source + Build Tools)

IMPORTANTE:
- Este pacote contém SÓ código-fonte C, assets placeholders e scripts de build. NÃO há binários ou ISOs aqui.
- Por limitações de segurança/política eu não posso gerar ou distribuir arquivos executáveis (.elf/.bin/.iso).
- Siga docs/build_windows7_detailed.md para compilar e gerar .bin/.cue no seu PC.

Conteúdo principal:
- src/           -> código-fonte (módulos organizados)
- assets/        -> texturas e modelos placeholder (substitua por suas artes)
- build_tools/   -> Makefile, SYSTEM.CNF, build_win32.bat (edite caminhos locais)
- docs/          -> passos detalhados e dicas para Game Stick M8
