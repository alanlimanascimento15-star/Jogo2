/* system stubs */
#include "system.h"
static int running=1;
void system_init(void){}
int system_running(void){return running;}
void system_update(void){}
void system_render(void){}
void system_shutdown(void){running=0;}
