/* world stub */
#include "world.h"
#include <stdlib.h>
static unsigned char *world=NULL; static int W,H,D;
void world_init(int w,int h,int d){W=w;H=h;D=d; world=(unsigned char*)malloc((size_t)W*H*D);}
void world_update(void){}
void world_render(void){}
