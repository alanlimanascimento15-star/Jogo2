void villages_init(void){}
