void system_init(void); int system_running(void); void system_update(void); void system_render(void); void system_shutdown(void);
