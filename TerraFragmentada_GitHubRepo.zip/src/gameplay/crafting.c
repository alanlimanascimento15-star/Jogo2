int craft_item(int id){ return 0; }
