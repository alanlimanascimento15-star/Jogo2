Guia rápido para Windows 7 (32-bit):
1) Instale PS1 SDK (psx-sdk) e mingw32-make.
2) Instale mkpsxiso (Windows build).
3) Edite build_tools/build_win32.bat: set PSX_SDK_BIN and MKPSXISO_BIN para seus caminhos.
4) Abra Prompt de Comando na pasta do projeto e rode: build_tools\build_win32.bat
5) Teste OUTPUT.BIN no DuckStation antes de copiar para Game Stick M8.
