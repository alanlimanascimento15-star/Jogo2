Terra Fragmentada – COOP Version (Source Package)
Esta é a estrutura base para criar a versão local multiplayer (split-screen).
