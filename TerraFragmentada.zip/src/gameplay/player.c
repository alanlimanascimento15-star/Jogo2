/* player stub */
#include "gameplay/player.h"
void player_init(void){}
void player_update(void){}
