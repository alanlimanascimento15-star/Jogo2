int mob_drop(int type){ return 0; }
