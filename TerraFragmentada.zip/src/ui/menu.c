/* ui stub */
#include "ui/menu.h"
#include <stdio.h>
void ui_init(void){}
void ui_update(void){}
void ui_show_main_menu(void){ printf("-- Terra Fragmentada --\n"); }
