void save_game(int slot){}
void load_game(int slot){}
