#include "system.h"
#include "world/world.h"
#include "gameplay/player.h"
#include "ui/menu.h"
int main(void){ system_init(); ui_init(); world_init(256,128,256); player_init(); ui_show_main_menu(); while(system_running()){ system_update(); world_update(); player_update(); ui_update(); system_render(); } system_shutdown(); return 0; }
